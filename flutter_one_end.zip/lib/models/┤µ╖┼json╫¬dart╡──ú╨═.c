// 1在postman中获取api返回来的json数据
//api请求地址
//http://mvs.bslmeiyu.com/api/v1/products/popular
//postman地址
//https://web.postman.co/workspace/My-Workspace~d8f25c06-68e4-41b6-86d3-ecf53ae7bdf0/request/create?requestId=8281b2fa-6f9c-4599-b41b-f5c6c35cc33e

// 2在转换json为dart的网址中进行模型转换
// 3存放在本目录中
//  4每个模型使用一个文件存放