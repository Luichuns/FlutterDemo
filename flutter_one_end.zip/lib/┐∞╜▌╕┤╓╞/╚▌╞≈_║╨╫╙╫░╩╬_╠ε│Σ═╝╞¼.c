Container(height: 10,
          margin: EdgeInsets.only(left: Dimensions.width10, right: Dimensions.width10),

          decoration: BoxDecoration(
                                    //边缘半径
                                    borderRadius: BorderRadius.circular(Dimensions.radius30),
                                    //轮播图用到index
                                    //填充颜色【填充颜色=单双数页面颜色不一样】
                                    //color: index.isEven ? Color(0xFF69c5df) : Color(0xFF9294cc),
                                    //填充图片
                                    image: DecorationImage(
                                                            //填充拉满
                                                            fit:BoxFit.cover,
                                                            image: AssetImage("images/gzn.jpg"),
                                                           ),
                                    ),
        ),
