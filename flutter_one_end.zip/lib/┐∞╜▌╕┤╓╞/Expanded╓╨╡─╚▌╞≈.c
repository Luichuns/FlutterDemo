Expanded(
        child: Container(
                        height: Dimensions.height100,
                        // width: Dimensions.width200,
                        decoration: BoxDecoration(color: Colors.black12,
                                                    borderRadius: BorderRadius.only(topRight: Radius.circular(Dimensions.height20),bottomRight: Radius.circular(Dimensions.height20),),
                                                 ),
                        ),
        ),
//Expanded会默认占满外面的容器空间