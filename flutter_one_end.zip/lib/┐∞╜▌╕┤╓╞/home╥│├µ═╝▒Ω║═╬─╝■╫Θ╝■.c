Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        //使用组合图标和文字组件
                        IconAndTextWidget(
                          icon: Icons.circle_sharp,
                          iconColor: AppColors.iconColor1,
                          text: "文字1",
                        ),
                        IconAndTextWidget(
                          icon: Icons.location_on,
                          iconColor: AppColors.mainColor,
                          text: "文字2",
                        ),
                        IconAndTextWidget(
                          icon: Icons.access_time_rounded,
                          iconColor: AppColors.iconColor2,
                          text: "文字3",
                        ),
                      ],
                    ),