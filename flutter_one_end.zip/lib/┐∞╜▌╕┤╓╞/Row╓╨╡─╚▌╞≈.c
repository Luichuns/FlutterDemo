Row(
     children: [
                Container(
                            width: 300,//需要给宽度才能显示
                            // height: double.infinity,
                            color: Colors.amber[600],
                         )
               ],
    ),

高度自动占满
在Row中的Container,默认高度为double.infinity,无穷/占满

需要定义容器宽度,默认为0，



Row(
    children: [
                Expanded(
                        Container(
                                    height:0,//需要给高度才能显示
                                    width:double.infinity,
                                ),
                       )
              ],
),

Row中的Expanded再套Container(),
Container的默认--高度为0,[必须写]
Container的默认--宽度占满父容器---[可不写]