Row(
  {"text":"排序对齐方式"},
    // mainAxisAlignment: MainAxisAlignment.center, //水平居中
    // mainAxisAlignment: MainAxisAlignment.end, //右对齐
    // mainAxisAlignment: MainAxisAlignment.spaceBetween, //两端对齐
    //mainAxisAlignment: MainAxisAlignment.spaceAround, //空格环绕
);
Row();