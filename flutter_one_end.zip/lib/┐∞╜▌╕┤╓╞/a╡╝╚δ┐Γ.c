import 'package:flutter/material.dart'; //安卓风格UI库
import 'package:flutter/cupertino.dart'; //IOS风格UI库
import 'dart:io'; //http请求
//http请求插件
import 'package:dio/dio.dart';//http请求插件
//第三方轮播图插件
import 'package:flutter_swiper/flutter_swiper.dart'; //第三方轮播图插件
//组件国际化语言库
import 'package:flutter_localizations/flutter_localizations.dart';//组件国际化语言库
import 'package:get/get.dart';//getX包


//导入主页的组件
// import 'package:my_app/home/home.dart';
// import 'package:my_app/home/a1.dart';
//文本与图标自定义组件
import 'package:my_app/widgets/icon_and_text_widget.dart'; //文本与图标自定义组件


import 'package:my_app/utils/dimensions.dart'; //自定义尺寸比例库
import 'package:my_app/utils/color.dart'; //自定义颜色组件
import 'package:my_app/widgets/big_text.dart'; //自定义大字体组件
import 'package:my_app/widgets/small_text.dart'; //自定义小字体组件
import 'package:dots_indicator/dots_indicator.dart'; //滑块点包 


import 'package:my_app/models/products_model.dart'; //自定义接口--产品数据模型库