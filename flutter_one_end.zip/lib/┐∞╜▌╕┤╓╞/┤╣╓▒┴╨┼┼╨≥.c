{"text":"排序对齐方式,主轴对齐"},
Column(
      //5选1
      mainAxisAlignment: MainAxisAlignment.start, //         起始方向
      mainAxisAlignment: MainAxisAlignment.end,//            末至对齐
      mainAxisAlignment: MainAxisAlignment.center, //          水平居中
      mainAxisAlignment: MainAxisAlignment.spaceBetween, //  两端对齐
      mainAxisAlignment: MainAxisAlignment.spaceAround, //   空格环绕
  );

  
{"text":"排序对齐方式,交叉轴对齐"},
Column(
//      crossAxisAlignment: CrossAxisAlignment.start, // 
//      crossAxisAlignment: CrossAxisAlignment.center, //          水平居中
//      crossAxisAlignment: CrossAxisAlignment.end,//              末至对齐
//      crossAxisAlignment: CrossAxisAlignment.baseline, //          起始方向
//      crossAxisAlignment: CrossAxisAlignment.stretch
//      crossAxisAlignment: CrossAxisAlignment.values//只在列表中使用
//      crossAxisAlignment: CrossAxisAlignment.spaceBetween, //    两端对齐
//      crossAxisAlignment: CrossAxisAlignment.spaceAround, //     空格环绕
  );