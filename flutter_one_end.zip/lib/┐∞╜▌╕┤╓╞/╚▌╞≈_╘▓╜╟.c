Container(
            height: Dimensions.pageViewTextContainer, //不给高度不显示
            margin: EdgeInsets.only(//外边距
                                    top:Dimensions.height15,
                                    left: Dimensions.width45,
                                    right: Dimensions.width45,
                                    bottom: Dimensions.height15,
                                  ),
            //装饰，盒子装饰
            decoration: BoxDecoration(
                                    //四个角全部
                                    //边缘半径     边缘半径      圆形
                                    borderRadius: BorderRadius.circular(Dimensions.radius30),
                                    //单个角
                                    borderRadius: BorderRadius.only(
                                                                    topRight: Radius.circular(Dimensions.height20),
                                                                    topLeft: Radius.circular(Dimensions.height20),
                                                                    bottomLeft: Radius.circular(Dimensions.height20),
                                                                    bottomRight: Radius.circular(Dimensions.height20),
                                                                    ),
                                    //填充颜色-用于测试
                                    color: Colors.blue[500],
                                    //添加阴影【阴影1，主要阴影颜色】【阴影2，添加白色阴影来调节,左右】
                                    boxShadow: const [
                                                        //【阴影位置offset: Offset(5, 5),】【模糊半径blurRadius: 5.0,】
                                                        BoxShadow(color: Color(0xFFe8e8e8),blurRadius: 5.0,offset: Offset(0, 5)),
                                                        BoxShadow(color: Colors.white, offset: Offset(-5, 0)),
                                                        BoxShadow(color: Colors.white, offset: Offset(5, 0)),
                                                    ],
                                    ),
        ),

///仅仅左右上角圆角
decoration: BoxDecoration(borderRadius: BorderRadius.only(topRight: Radius.circular(Dimensions.height20),topLeft: Radius.circular(Dimensions.height20), ),),


///仅仅左右上角圆角+背景颜色为白色
decoration: BoxDecoration(color: Colors.white,borderRadius: BorderRadius.only(topRight: Radius.circular(Dimensions.height20),topLeft: Radius.circular(Dimensions.height20), ),),

///仅右上角圆角
decoration: BoxDecoration(borderRadius: BorderRadius.only(topRight: Radius.circular(Dimensions.height20))),