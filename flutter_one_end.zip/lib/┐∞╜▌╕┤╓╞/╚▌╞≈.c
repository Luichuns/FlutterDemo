import 'package:flutter/material.dart';

class name extends StatelessWidget {
  const name({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: 0,
      margin: 1,
      height: 100,
      width: 100,
      color: Colors.black12,
      alignment: AlignmentDirectional.bottomCenter,
      child: Container(),
    );
  }
}
//容器---高度【】---宽度【】---填充颜色【】----对齐方向【alignment】---外边距【margin】--内边距【padding】---子组件【child】--【容器标记】