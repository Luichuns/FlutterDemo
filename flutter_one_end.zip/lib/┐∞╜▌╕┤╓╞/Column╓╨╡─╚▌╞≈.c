Column(
        children: [
                    Container(
                            // width: double.infinity,
                            height: 300,
                            color: Colors.amber[600],
                            )
                    ],
      ),

宽度自动占满
在Column中的Container默认宽度为double.infinity,无穷/占满
需要定义容器高度,默认为0