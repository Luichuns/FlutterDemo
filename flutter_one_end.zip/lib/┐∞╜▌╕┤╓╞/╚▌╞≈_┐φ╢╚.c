Container(
//width: double.infinity,//宽度填满
//width: double.maxFinite//最大屏幕
//width: double.minPositive//
//width: double.nan//
//width: double.negativeInfinity//
width:10,//直接填像素
),



          //在Column下的容器默认宽度为0
          //在Column下的容器默认高度为最大父容器高度