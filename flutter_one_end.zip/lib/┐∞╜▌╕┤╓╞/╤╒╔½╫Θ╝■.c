默认
// color: Colors.red,//普通
// color: Colors.blue[100], //浅颜色
// color: Colors.blue[900], //深颜色



ARGB
// color: Color.fromARGB(0xFF, 0x00, 0xFF, 0x00), //定制颜色,可写十六进制颜色
// color: Color.fromARGB(255, 255, 0, 255), //定制颜色,可写十进制颜色



ARGO
// color: Color.fromRGBO(255, 0, 0, 1.0不透明), //定制颜色
// color: Color.fromRGBO(255, 0, 0, 0透明), //定制颜色