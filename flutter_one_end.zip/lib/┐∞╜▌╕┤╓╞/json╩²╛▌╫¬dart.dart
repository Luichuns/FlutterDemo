void main() {
  var aMap = {
    "key1": "值1",
    "key2": 2222,
    "key3": "值3",
    "key4": [
      {"k4_1": "数字1", "k4_2": 41},
      {"k4_1": "数字2", "k4_2": 42}
    ]
  };

  //从后端获取到的数据是json数据格式
  //其他人叫json的键值对，我叫它为项值，
  //key=项
  //value=值
  //需要把json转换为dart中的Map类型数据，转化后的数据如上面
  //
  //获取到第一层的第4个项的值，赋值给key4BL变量
  //把key4BL转为一个列表类型,并且遍历每个元素，然后通过每个元素执行一次【print(element["dkey"])】
  // var key4BL = aMap["key4"];
  // (key4BL as List).forEach((element) {
  //   print(element["key4"]);
  // });
  //
  //
  //使用
  //使用上面的aMap变量,和定义好的模型class JieShou()  来创建对象
  var obj = JieShou.fromJson(aMap);
  //使用测试
  print(obj.key1); //值1
  print(obj.key2); //2222
  print(obj.key3); //值3
  print(obj.key4); //[Instance of 'Key4', Instance of 'Key4']
  var liebiao = obj.key4;
  // liebiao.map((e) => null)
  //需要不为空

  liebiao!.map((e) => {print(e.k4_1)}).toList();

  liebiao.map((e) => {print(e.k4_2)});
}

//json数据如上面所示
//那么再dart中  可以创建类来接收

class JieShou {
  //上面的json数据，第一层有4项，对应有4个值,这里创建4个变量来接收值
  //因为不同的值的类型不一样，定义变量值类型需要区分
  String? key1;
  int? key2;
  String? key3;
  List<Key4>? key4;
  //下面另外定义了Key4的class 模型

  //构造函数传递变量,本个类定义的变量
  JieShou({this.key1, this.key2, this.key3, this.key4});

  //(Map<String, dynamic> json)
  //其他人叫json的键值对，我叫它为项值，
  //key=项
  //value=值
  //第一层项，都是字符串类型--所以定义为String类型
  //第一层值，有字符串类型，有数值类型，也有列表类型，所以定义为dynamic类型[任意类型]

  //formJson()方法
  //定义参数json 的类型
  //使用String 类型接收 项 "key1","key2","key3","key4"
  //使用dynamic类型接收 值 "aa1", 2222,"cccc3",[{"dkey": "数字1", "k4_1": 1},{"dkey": "数字2", "k4_1": 2}]
  JieShou.fromJson(Map<String, dynamic> json) {
    key1 = json['key1'];
    key2 = json['key2'];
    key3 = json['key3'];
    //上面定义了变量key4 的Key4模型 列表类型，并且允许为空，所以进行判断是否为空
    if (json['key4'] != null) {
      //第四个项的值是一个列表类型
      //判断如果key4中的值 不是空 就执行
      key4 = <Key4>[];
      //先创建key4变量，并且定义好数据类型为<Key4>[];

      // json["key4"].forEach((){});调用失败
      // json["key4"]它并不是纯List类型，
      //                 而是Map中的List，所以会提示 null null
      // 想要使用forEach()方法，需要纯List类型
      // (json['key4'] as List)转换为列表
      // (json['key4'] as List).forEach((e){});
      (json['key4'] as List).forEach((e) {
        key4!.add(Key4.fromJson(e));
        //key4使用!断言，说明它不是空
      });
    }
  }
  //上面使用了JieShou这个 类，并且有4个属性  [key1,key2,key3,key4]
  //可以定义一个变量 jj，类型定义为JieShou
  // JieShou jj;
  // 然后通过变量jj的来访问属性
  //jj.key1
  //jj.key2
  //jj.key3
  //jj.key4
}

class Key4 {
  //[{"k4_1": "数字1", "k4_2": 1},{"k4_1": "数字2", "k4_2": 2}]
  // 如上行中的的数据
  String? k4_1; //存储 "数字1"  "数字2"
  int? k4_2; //存储 1  2

  //构造函数传递变量,本个类定义的变量
  Key4({this.k4_1, this.k4_2});
  //

  Key4.fromJson(Map<String, dynamic> json) {
    k4_1 = json['k4_1'];
    k4_2 = json['k4_2'];
  }
}
//==========================================================
//从嵌套的json中创建一个模型
