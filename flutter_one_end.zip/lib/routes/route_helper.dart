import 'package:get/get.dart';
import 'package:my_app/pages/food/popular_food_detail.dart';
import 'package:my_app/pages/food/recommended_food_detail.dart';
import 'package:my_app/pages/home/main_food_page.dart';

class RouteHelper {
  static const String initial = "/";
  static String getInitail() => "$initial";

  static const String popularFood = "/popular-food";
  static String getPpularFood(int pageId) => "$popularFood?pageId=$pageId";

  static const String recommendedFood = "/recommended-food";
  static String getrecommendedFood(int pageId) =>
      "$recommendedFood?pageId=$pageId";

  static List<GetPage> routes = [
    GetPage(name: initial, page: () => MainFoodPage()),
    // GetPage(name: popularFood, page: () => PopularFoodDetail()),
    GetPage(
        name: popularFood,
        page: () {
          var pageId = Get.parameters["pageId"];
          print("受欢迎的食物,路由调用");
          return PopularFoodDetail(pageId: int.parse(pageId!));
        },
        //跳转时使用的跳转动画效果Transition.fadeIn
        transition: Transition.fadeIn),
    GetPage(
        name: recommendedFood,
        page: () {
          var pageId = Get.parameters["pageId"];
          print("受欢迎的食物,路由调用");
          return RecommendedFoodDetail(pageId: int.parse(pageId!));
        },
        //跳转时使用的跳转动画效果Transition.fadeIn
        transition: Transition.fadeIn),
  ];
}
