bottomNavigationBar
​底部导航条，常用于切换底部 item

使用方法

int _currentIndex = 0;
List<Widget> _pages = [Center(child: Text("tab1"),),
                       Center(child: Text("tab2"),),
                      ];

Scaffold(
        appBar: AppBar(title: Text("Scaffold"),),
        body: _pages[_currentIndex],
        bottomNavigationBar: BottomNavigationBar(
                                                currentIndex: _currentIndex,
                                                onTap: (currentIndex) {setState(() {_currentIndex = currentIndex;});},
                                                items: [
                                                        BottomNavigationBarItem(label: "tab1",icon: Icon(Icons.settings)),
                                                        BottomNavigationBarItem(label: "tab2",icon: Icon(Icons.settings)),
                                                       ],

                                                ),
        );