onEndDrawerChanged
右侧抽屉菜单改变事件回调，使用方式和 onDrawerChanged 一样。

使用方法

GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
  	                    title: Text("Scaffold"),
                        leading: IconButton(icon: Icon(Icons.menu_open),
                                            onPressed: (){_scaffoldKey.currentState.openDrawer();},
                                           ),
                        ),
          body: Center(child: Text("body"),),
	        drawer: Drawer(child: Center(child: Text("draw"),),),
        //   onDrawerChanged: (isOpen) {print(isOpen);},//左侧
          onEndDrawerChanged: (isOpen) {print(isOpen);},//右侧
);