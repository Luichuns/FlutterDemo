drawer

左侧抽屉菜单组件，如果需要自定义可通过设置 Scaffold 的 key 来操作手动打开侧边栏，代码如下


GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
                        title: Text("Scaffold"),
                        leading: IconButton(icon: Icon(Icons.menu_open),
                                            onPressed: (){_scaffoldKey.currentState.openDrawer();},
                                           ),
                        ),
          body: Center(child: Text("body"),),
          drawer: Drawer(child: Center(child: Text("draw"),),),
);