endDrawer

右侧抽屉菜单组件,功能和 drawer 一样，唯一的区别是一个在左侧，一个在右侧。

使用方法
GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey();

Scaffold(
          key: _scaffoldKey,
          appBar: AppBar(
  	                    title: Text("Scaffold"),
                        leading: IconButton(icon: Icon(Icons.menu_open),
                                            onPressed: (){_scaffoldKey.currentState.openDrawer();},
                                           ),
                        ),
          body: Center(child: Text("body"),),
	    //   drawer: Drawer(child: Center(child: Text("draw"),),),
          endDrawer: Drawer(child: Center(child: Text("draw"),),),
);





 
   
  
 
