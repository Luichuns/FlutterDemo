import 'package:get/get.dart';
import 'package:my_app/utils/app_constants.dart';

class ApiClient extends GetConnect implements GetxService {
  //令牌
  late String token;
  //链接服务器的url
  final String appBaseUrl;

  //_mainHeaders 字典类型数据 key字符 value字符
  late Map<String, String> _mainHeaders;
  //
  // ApiClient() {}
  ApiClient({required this.appBaseUrl}) {
    baseUrl = appBaseUrl;
    //超时 时间
    timeout = Duration(seconds: 30);
    token = AppConstants.TOKEN; //令牌常量
    //准备标头信息，应用接收json数据，类型为UTF-8----token令牌，
    _mainHeaders = {
      'Content-type': 'application/json; charset=UTF-8',
      'Authorization': 'Bearer $token',
    };
  }
  Future<Response> getData(String uri) async {
    //1长视获取数据
    //因为是异步,get()方法前需要使用await，表示等待io
    //使用类型Response，变量名是resoponse， 来接收返回的数据
    //并且把获取到的数据，返回给调用的函数
    try {
      //先找找基本网址uri，主网站www.luichun.com
      Response response = await get(uri);
      return response;
    } catch (e) {
      //如果不能获取数据
      //尝试抓取错误
      //返回状态码=1，状态错误文本 e  ，e需要转换为字符串格式返回
      return Response(statusCode: 1, statusText: e.toString());
    }
  }
}


//数据传递给repository/popular_product_repo.dart
//api请求地址
//http://mvs.bslmeiyu.com/api/v1/products/popular
//postman地址
//https://web.postman.co/workspace/My-Workspace~d8f25c06-68e4-41b6-86d3-ecf53ae7bdf0/request/create?requestId=8281b2fa-6f9c-4599-b41b-f5c6c35cc33e