import 'package:get/get.dart';
import 'package:my_app/data/api/api_client.dart';
import 'package:my_app/utils/app_constants.dart';

//使用get.dart库来链接互联网，需创建一个类来继承GetxService类
//接收data/api/api_client.dart的ApiClient
class PopularProductRepo extends GetxService {
  //1创建一个变量，类型为ApiClient
  //这个ApiClient的类型来自于import 'package:my_app/data/api/api_client.dart';
  final ApiClient apiClient;

  //2构造函数
  //每次调用这个类时，都必须传递的信息apiClient
  PopularProductRepo({required this.apiClient});

  //3创建一个异步函数，获取服务器返回的数据
  // Future<Response> getPopularProductList() async{}
  Future<Response> getPopularProductList() async {
    // return await apiClient.getData("end point url");
    //返回 异步 api客户端链接的获取数据方法(网址);
    // return await apiClient.getData("https://www.dbestech.com.api/product/list");6-7 46分更改
    return await apiClient.getData(AppConstants.POPULAR_PRODUCT_URI);
  }
}

//输入传递给controllers/popular_product_controller.dart文件
