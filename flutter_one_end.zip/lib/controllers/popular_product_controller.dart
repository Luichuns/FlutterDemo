import 'package:flutter/material.dart';
import 'package:my_app/controllers/cart_controller.dart';
import 'package:my_app/data/repository/popular_product_repo.dart';
import 'package:my_app/models/cart_model.dart';
import 'package:my_app/models/products_model.dart';
import 'package:get/get.dart';
import 'package:my_app/utils/color.dart';

class PopularProductController extends GetxController {
  final PopularProductRepo popularProductRepo;
  PopularProductController({required this.popularProductRepo});
  List<ProductModel> _popularProductList = [];
  List<ProductModel> get popularProductList => _popularProductList;
  late CartController _cart;
  //<ProductModel> 7-8 0026添加
  bool _isLoaded = false; //加载的标记值  私有变量
  bool get isLoaded => _isLoaded; //获取私有变量的值
  int _quantity = 0; //数量初始值
  //获取数量方式1//int get quantity => _quantity;
  int get quantity => _quantity;
  //获取数量方式2//int get quantity {return _quantity;}
  // int get quantity {return _quantity;}

  //购物车物品数量
  int _inCartItems = 0;
  //获取购物车物品的数量= 已经在购物车的+本个页面的数量
  int get inCartItems => _inCartItems + _quantity;

  Future<void> getPopularProductList() async {
    Response response = await popularProductRepo.getPopularProductList();
    if (response.statusCode == 200) {
      print("获取产品信息");
      _popularProductList = [];
      _popularProductList.addAll(Product.fromJson(response.body).products);
      //打印下获取到的产品列表信息
      print(_popularProductList);
      //[加载标记值] 更改私有变量
      _isLoaded = true;
      update();
    } else {}
  }

  void setQuantity(bool isIncrement) {
    if (isIncrement) {
      //增加
      print("点击--添加--1次,目前的值为$_quantity");

      // _quantity = _quantity + 1;
      //使用检查数量 方法来执行
      _quantity = checkQuantity(quantity + 1);
    } else {
      //减少
      print("减少1成功,目前的值为$_quantity");
      _quantity = checkQuantity(quantity - 1);
    }
    update(); //必须添加更新，否则ui不知道更新了数据
  }

  //检查数量函数
  //逻辑  最小为0，最多20-,其它的返回其它--小于0时，那么返回0，最小为0   大于20时，只有20，最多20，其它1-19时返回1-19
  int checkQuantity(int quantity) {
    if ((_inCartItems + quantity) < 0) {
      //小于0时弹窗提示
      Get.snackbar(
        "单个物品,最小值为0",
        "提示信息1",
        backgroundColor: AppColors.mainColor,
        colorText: Colors.white,
      );
      if (_inCartItems > 0) {
        _quantity = -_inCartItems;
        return _quantity;
      }
      return 0;
    } else if ((_inCartItems + quantity) > 20) {
      //
      Get.snackbar(
        "单个物品,最大添加20个",
        "提示信息2",
        backgroundColor: AppColors.mainColor,
        colorText: Colors.white,
      );
      return 20;
    } else {
      return quantity;
    }
  }

  //每次打开新的页面时，需要重置为0
  void initProduct(ProductModel product, CartController cart) {
    _quantity = 0;
    _inCartItems = 0;
    _cart = cart;
    //如果存在
    //从本地存储中获取数量

    //
    //10-11 0229
    var exist = false;
    exist = _cart.existInCart(product);
    print("exist的值为:" + exist.toString());

    if (exist) {
      _inCartItems = cart.getQuantity(product);
    }
    print("购物车中的数量是" + _inCartItems.toString());
  }

  void addItem(ProductModel product) {
    _cart.addItem(product, _quantity);
    _quantity = 0; //添加完之后数量值重置为0

    //购物车中的数量=车中的产品数量
    _inCartItems = _cart.getQuantity(product);
    //
    //
    _cart.items.forEach((key, value) {
      print("这ID是" + value.id.toString() + "这数量是" + value.quantity.toString());
    });
    update();
  }

  //
  //
  int get totalItems {
    return _cart.totalItems;
  }

  //
  //
  //
  //从
  List<CartModel> get getItems {
    return _cart.getItems;
  }
}
