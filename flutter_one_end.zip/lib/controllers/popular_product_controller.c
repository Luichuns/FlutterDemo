//
import 'package:get/get.dart';

import '../data/repository/popular_product_repo.dart';

//接收repository/popular_product_repo.dart的PopularProductRepo
class PopularProductController extends GetxController {
  final PopularProductRepo popularProductRepo;

  //使用构造函数来接受这个变量，创建实例
  PopularProductController({required this.popularProductRepo});

  //一个动态的列表类型,初始化为空
  //获取到数据再添加进去
  List<dynamic> _popularProductList = [];

  //获取上面的私有变量的方法
  List<dynamic> get popularProductList => _popularProductList;

  //异步接收
  Future<void> getPopularProductList() async {
    //获取对象列表，产品的列表，从服务器中获取产品列表
    Response response = await popularProductRepo.getPopularProductList();
    //对接收到的相应进行判断
    if (response.statusCode == 200) {
      _popularProductList = [];
      _popularProductList.addAll(Product.fromJson(response.body).products);
      //更新
      update();
    } else {}
  }
}
