//购物车控制器
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_app/data/repository/cart_repo.dart';
import 'package:my_app/models/cart_model.dart';
import 'package:my_app/models/products_model.dart';
import 'package:my_app/utils/color.dart';

class CartController extends GetxController {
  //import 'package:my_app/data/repository/cart_repo.dart';
  final CartRepo cartRepo;
  CartController({required this.cartRepo});
  // import 'package:my_app/models/cart_model.dart';
  Map<int, CartModel> _items = {};
  Map<int, CartModel> get items => _items;
  // import 'package:my_app/models/products_model.dart';
  void addItem(ProductModel product, int quantity) {
    var totalQiantity = 0;
    //9-10 47:45
    if (_items.containsKey(product.id!)) {
      _items.update(product.id!, (value) {
        totalQiantity = quantity + value.quantity!;
        return CartModel(
          id: value.id,
          name: value.name,
          price: value.price,
          img: value.img,
          quantity: value.quantity! + quantity,
          isExist: true, //数量是否存在,因为正在传递，为真
          time: DateTime.now().toString(), //使用当前时间 --字符串类型
        );
      });
      //如果总数量等<=0 删除掉这项
      if (totalQiantity <= 0) {
        _items.remove(product.id);
      }
    } else {
      if (quantity > 0) {
        _items.putIfAbsent(product.id!, () {
          // print(product.id!.toString());
          // print("产品的数量" + quantity.toString());
          // print("把项目添加到购物车");
          // _items.forEach((key, value) {
          //   print("数量是" + value.quantity.toString());
          // });
          return CartModel(
            id: product.id,
            name: product.name,
            price: product.price,
            img: product.img,
            quantity: quantity,
            isExist: true, //数量是否存在,因为正在传递，为真
            time: DateTime.now().toString(), //使用当前时间 --字符串类型
          );
        });
      } else {
        //小于0时弹窗提示
        Get.snackbar(
          "小于0了",
          "出现弹窗,应该至少添加1个项目 到购物车中",
          backgroundColor: AppColors.mainColor,
          colorText: Colors.white,
        );
      }
    }
    //
    print("获取到列表的长度" + _items.length.toString());
  }

  //
  bool existInCart(ProductModel product) {
    if (_items.containsKey(product.id)) {
      return true;
    }
    return false;
  }

  //
  //获取数量
  //
  int getQuantity(ProductModel product) {
    //数量为0
    //如果 给出的列表中有 则获取列表中的数量值
    //最后返回数量值

    //参数类型 产品模型    产品
    var quantity = 0;

    //
    //第一个判断条件
    //列表  关联的键   产品id---在products_model.dart中ProductModel 类的属性
    //遍历
    //第二个判断条件
    //
    if (_items.containsKey(product.id)) {
      _items.forEach((key, value) {
        if (key == product.id) {
          quantity = value.quantity!;
        }
      });
    }
    return quantity;
  }

  //
  //
  int get totalItems {
    var totalQuantity = 0;
    _items.forEach((key, value) {
      totalQuantity = totalQuantity + value.quantity!;
    });
    return totalQuantity;
  }

  //
  //
  //
  //Map<int, CartModel> _items = {};在这里面获取
  //CartModel的属性{id name price img quantity isExist time}
  //_items.entries 是条目属性
  //https://api.flutter.dev/flutter/dart-core/Map/entries.html
  //https://api.flutter.dev/flutter/package-collection_collection/CanonicalizedMap/entries.html
  //
  //从Map<int, CartModel> 转换为 List<CartModel>
  List<CartModel> get getItems {
    //_items.entries.map((e) => null);的意思是循环这个模型列表 条目
    //模型是excel表中的每一列的意思
    //_items就是数据的所有行 中的 值 的集合
    //_items.entries.map((e) => null); e 就是每一行中的数据
    //循环遍历这个数据表
    //_items.entries.map((e) => null);==把箭头函数按更换为可读强的{}==_items.entries.map((e) {});
    return _items.entries.map((e) {
      return e.value;
    }).toList();
    //因为这里定义返回的的类型是List<CartModel>
    //需要添加return
    //返回相对应的数据类型内容
  }
  //
}
