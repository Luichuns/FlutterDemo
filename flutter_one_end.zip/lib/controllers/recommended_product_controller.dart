//这是推荐产品的控制器
//创建了控制器，就创建一个repo
//repo文件再data文件夹中
import 'package:my_app/data/repository/recommended_product_repo.dart';
import 'package:my_app/models/products_model.dart';
import 'package:get/get.dart';

class RecommendedProductController extends GetxController {
  final RecommendedProductRepo recommendedProductRepo;
  RecommendedProductController({required this.recommendedProductRepo});
  List<ProductModel> _recommendedProductList = [];
  List<ProductModel> get recommendedProductList => _recommendedProductList;
  //<ProductModel> 7-8 0026添加
  bool _isLoaded = false; //加载的标记值  私有变量
  bool get isLoaded => _isLoaded; //获取私有变量的值
  Future<void> getRecommendedProductList() async {
    Response response =
        await recommendedProductRepo.getRecommendedProductList();
    if (response.statusCode == 200) {
      print("获取推荐数据信息");
      _recommendedProductList = [];
      _recommendedProductList.addAll(Product.fromJson(response.body).products);
      //打印下获取到的产品列表信息
      print(_recommendedProductList);
      //[加载标记值] 更改私有变量
      _isLoaded = true;
      update();
    } else {
      print("无法获取到数据");
    }
  }
}
