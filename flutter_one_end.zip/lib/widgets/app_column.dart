import 'package:flutter/material.dart';
import 'package:my_app/widgets/small_text.dart';

import '../utils/color.dart';
import '../utils/dimensions.dart';
import 'big_text.dart';
import 'icon_and_text_widget.dart';

class AppColumn extends StatelessWidget {
  //创建需要传递的参数
  final String text;
  const AppColumn({Key? key, required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start, //左边对齐
      children: [
        BigText(
          text: text,
          size: Dimensions.font26,
        ),
        SizedBox(height: Dimensions.height10),
        Row(
          children: [
            Wrap(
              children: List.generate(
                  5,
                  (index) => Icon(
                        Icons.star,
                        color: AppColors.mainColor,
                        size: Dimensions.font15,
                      )),
            ),
            //两种方式，生成列表生成式
            // children:List.generate(5,(index) { return Icon(Icons.start,color: AppColors.mainColor,size: 15,);})
            // children:List.generate(5,(index) => Icon(Icons.start,color: AppColors.mainColor,size: 15,)),
            SmallText(text: "文字2"),
            SizedBox(
              width: Dimensions.width15,
            ),
            SmallText(text: "文字3"),
          ],
        ),
        SizedBox(
          height: Dimensions.height10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            //使用组合图标和文字组件
            IconAndTextWidget(
              icon: Icons.circle_sharp,
              iconColor: AppColors.iconColor1,
              text: "文字1",
            ),
            IconAndTextWidget(
              icon: Icons.location_on,
              iconColor: AppColors.mainColor,
              text: "文字2",
            ),
            IconAndTextWidget(
              icon: Icons.access_time_rounded,
              iconColor: AppColors.iconColor2,
              text: "文字3",
            ),
          ],
        ),
      ],
    );
  }
}
