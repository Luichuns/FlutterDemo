import 'package:flutter/material.dart';
import 'package:my_app/utils/color.dart';
import 'package:my_app/widgets/small_text.dart';

import '../utils/dimensions.dart';

class ExpandableTextWidget extends StatefulWidget {
  //这是一个有状态的类
  //创建1个text变量来装字符串
  //并且传递text变量给组件调用
  final String text;
  ExpandableTextWidget({Key? key, required this.text}) : super(key: key);

  @override
  State<ExpandableTextWidget> createState() => _ExpandableTextWidgetState();
}

class _ExpandableTextWidgetState extends State<ExpandableTextWidget> {
  //创建后面才传入值的变量
  //firstHalf  和 secondHalf
  //隐藏文字 默认为真
  //文本高度为100
  late String firstHalf;
  late String secondHalf;
  bool hiddenText = true; //默认为真/隐藏时为真，不隐藏为假
  double textHeight = Dimensions.height100; //显示文本的高度,100/844

  //每当初始化时=============
  @override
  void initState() {
    super.initState();
    // 对文本长度进行判断
    // 文本是不是超过textHeight这个数量
    // 对组件中的text变量进行长度判断
    // 当text中的长度 大于 显示文本高度
    // 前一半=  texe属性的文字 取前面（0----显示文本高度像素数值）
    // 后一半=  texe属性的文字 取前面（显示文本高度像素数值+1----texe属性长度末尾）
    // 否则  当text中的长度 小于或等于 显示文本高度
    // 前一半=text
    // 后一半=null
    if (widget.text.length > textHeight) {
      print("输出textHeight.toInt()");
      print(textHeight.toInt());
      print(Dimensions.height100);
      firstHalf = widget.text.substring(0, textHeight.toInt());
      secondHalf =
          widget.text.substring(textHeight.toInt() + 1, widget.text.length);
    } else {
      firstHalf = widget.text;
      secondHalf = "";
    }
  }

  //初始化重写=============
  @override
  Widget build(BuildContext context) {
    return Container(
      child: secondHalf.isEmpty
          ? SmallText(text: firstHalf)
          : Column(
              children: [
                SmallText(
                    height: 1.8,
                    //隐藏时文字大小为12，非隐藏时为15
                    size: hiddenText ? Dimensions.font12 : Dimensions.font15,
                    //隐藏时
                    //显示文字为前一半+...
                    //非隐藏时
                    //前一半+后一半
                    text: hiddenText
                        ? (firstHalf + "...")
                        : (firstHalf + secondHalf)),
                //触发 bool hiddenText = true;的相反值
                //文本展示按钮
                InkWell(
                  onTap: () {
                    setState(() {
                      hiddenText = !hiddenText; //每次点击等于相反
                    });
                  },
                  child: Row(
                    children: [
                      SmallText(
                        text: hiddenText ? "展示更多" : "关闭展示",
                        color: AppColors.mainColor,
                      ),
                      Icon(
                        //制作条件检查给与上下箭头
                        hiddenText
                            ? Icons.arrow_drop_down
                            : Icons.arrow_drop_up,
                        color: AppColors.mainColor,
                      )
                    ],
                  ),
                )
              ],
            ),
    );
  }
}
