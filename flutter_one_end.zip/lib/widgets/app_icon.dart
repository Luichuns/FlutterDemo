import 'package:flutter/material.dart';
import 'package:my_app/utils/color.dart';
import 'package:my_app/utils/dimensions.dart';

class AppIcon extends StatelessWidget {
  final IconData icon; //传递过来的参数//图标名字
  final Color backgroundColor; //图标背景色
  final Color iconColor; //图标颜色
  final double size; //图标轮廓大小
  final double iconSize; //图标大小设置
  AppIcon({
    Key? key,
    required this.icon,
    this.backgroundColor = const Color(0xFFfcf4e4),
    this.iconColor = const Color(0xFF756d54),
    this.size = 40,
    this.iconSize = 16,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(size / 2),
          color: backgroundColor),
      child: Icon(icon, color: iconColor, size: iconSize),
    );
  }
}
