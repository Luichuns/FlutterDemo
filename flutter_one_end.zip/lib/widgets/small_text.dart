import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
// import 'package:my_app/utils/dimensions.dart';

class SmallText extends StatelessWidget {
  final Color? color;
  final String text;
  double size;
  double height;

  SmallText({
    Key? key,
    this.color = const Color(0xFFccc7c5),
    required this.text,
    this.size = 12,
    this.height = 1.2,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        fontFamily: 'NotoSerif',
        color: color,
        fontSize: size,
        height: height,
      ),
    );
  }
}
