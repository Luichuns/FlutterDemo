//轮播图组件
import 'package:flutter/material.dart'; //
import 'package:get/get.dart';
import 'package:my_app/controllers/popular_product_controller.dart';
import 'package:my_app/utils/color.dart'; //自定义颜色组件
import 'package:my_app/widgets/app_column.dart';
import 'package:my_app/widgets/icon_and_text_widget.dart'; //文本与图标自定义组件
import 'package:dots_indicator/dots_indicator.dart'; //滑块点包
import 'package:my_app/utils/dimensions.dart'; //自定义容器在不同屏幕中的尺寸比例包
//自定义字体组件
import 'package:my_app/widgets/big_text.dart'; //自定义大字体组件
import 'package:my_app/widgets/small_text.dart'; //自定义小字体组件

//食物页面
class FoodPageBody extends StatefulWidget {
  FoodPageBody({Key? key}) : super(key: key);

  @override
  State<FoodPageBody> createState() => _FoodPageBodyState();
}

class _FoodPageBodyState extends State<FoodPageBody> {
  //页面控制器//默认值1.0// PageController pageController = PageController(viewportFraction: 1.0);
  final PageController pageController = PageController(
    viewportFraction: 0.85,
    initialPage: 1,
  );
  var _currPageValue = 0.0; //当前页面值
  final double _scaleFactor = 0.8; //比例因数
  final double _height =
      Dimensions.pageViewContainer; // double _height = 220;//2时13分修改

  @override //重写初始化方法，左右移动页面时
  void initState() {
    super.initState();
    pageController.addListener(() {
      setState(() {
        _currPageValue = pageController.page!;
        print("Current value is" + _currPageValue.toString()); //打印这个变化的值
      });
    });
  }

  @override //重写关闭
  void dispose() {
    pageController.dispose();
  }

  @override //
  Widget build(BuildContext context) {
    return Column(
      children: [
        //7-8创建 00 创建嵌套Container到GetBuilder里面
        GetBuilder<PopularProductController>(builder: (popularProducts) {
          return Container(
            // width: double.infinity,
            height: Dimensions.height320, ////2时17分修改
            child: PageView.builder(
              scrollDirection: Axis.horizontal, //水平方向滚动
              // Axis scrollDirection = Axis.horizontal,//轴 滚动方向= Axis.horizo​​ntal ,
              reverse: false, //反向？//   bool reverse = false,//布尔 反向=假，
              controller: pageController, //页面控制器[controller: pageController,]
              //   PageController? controller,//页面控制器？ 控制器，
              //   ScrollPhysics? physics,//滚动物理？ 物理学,
              //   bool pageSnapping = true,
              //   void Function(int)? onPageChanged,
              itemBuilder: (context, position) {
                return _buildPageItem(
                    position, popularProducts.popularProductList[position]);
              },
              //   required Widget Function(BuildContext, int) itemBuilder,
              //   int? Function(Key)? findChildIndexCallback,//子索引获取器？ findChildIndexCallback ,
              itemCount: popularProducts.popularProductList.length, //设置多少个轮播图？
              // itemCount: 5, //设置多少个轮播图？
              //   int? itemCount,//诠释？ 项目计数，设置多少个轮播图
              //   DragStartBehavior dragStartBehavior = DragStartBehavior.start,
              //   bool allowImplicitScrolling = false,
              //   String? restorationId,//字符串？ 恢复 ID
              //   Clip clipBehavior = Clip.hardEdge,//剪辑 clipBehavior = Clip.hardEdge
              //   ScrollBehavior? scrollBehavior,
              //   bool padEnds = true,
            ),
          );
        }),
        //7-8 0350 更改嵌套
        //构建的点数等于网络传过来的列表长度
        ////当网络获取到的数据是空的，那么显示1个点
        //当有网络数据，有N个数据，显示N个点
        GetBuilder<PopularProductController>(builder: (popularProducts) {
          return DotsIndicator(
            dotsCount: popularProducts.popularProductList.isEmpty
                ? 1
                : popularProducts.popularProductList.length, //固定点数//通过网络获取数量长度
            position: _currPageValue, //定位：当前页面值
            decorator: DotsDecorator(
              activeColor: AppColors.mainColor, //选中时的下标点颜色
              size: const Size.square(6.0), //未选中的大小
              activeSize: const Size(18.0, 6.0), //选中后的大小[宽度，大小]
              activeShape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5.0)),
            ),
          );
        }),

        //和轮播图对应的滑动块，圆点
        //================//官网源码new DotsIndicator(dotsCount: pageLength,position: currentIndexPage,decorator: DotsDecorator(size: const Size.square(9.0),activeSize: const Size(18.0, 9.0),activeShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),),);
        //距离滑动点30像素
        SizedBox(
          height: Dimensions.height30,
        ),
        //=====下面列表的标题
        Container(
          margin: EdgeInsets.only(left: Dimensions.width30),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              BigText(text: "热卖"),
              SizedBox(
                width: Dimensions.width10,
              ),
              Container(
                margin: const EdgeInsets.only(bottom: 3),
                child: BigText(
                  text: ".",
                  color: Colors.black87,
                ),
              ),
              SizedBox(
                width: Dimensions.width10,
              ),
              Container(
                margin: const EdgeInsets.only(bottom: 2),
                child: SmallText(
                  text: "好评推荐",
                  color: Colors.black26,
                ),
              ),
            ],
          ),
        ),
        //=====下面列表的标题
        //====================列表部分
        //====================列表部分

        ListView.builder(
          //不起作用
          // physics: AlwaysScrollableScrollPhysics(), //可以物理滚动
          physics: NeverScrollableScrollPhysics(), //设置不可以物理滚动
          shrinkWrap: true,
          //不起作用
          itemCount: 10,
          itemBuilder: (context, index) {
            return Container(
              margin: EdgeInsets.only(
                left: Dimensions.width20,
                right: Dimensions.width20,
                bottom: Dimensions.height10,
              ),
              child: Row(
                children: [
                  //左边商品图片
                  Container(
                    height: Dimensions.height120,
                    width: Dimensions.width120,
                    decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(Dimensions.radius20),
                        color: Colors.white38,
                        image: DecorationImage(
                          fit: BoxFit.cover,
                          image: AssetImage("images/gz.jpg"),
                        )),
                  ),
                  //右边文字
                  Expanded(
                    child: Container(
                      height: Dimensions.height100,
                      //Expanded会默认占满外面的容器空间
                      // width: Dimensions.width200,
                      decoration: BoxDecoration(
                        color: Colors.black12,
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(Dimensions.height20),
                          bottomRight: Radius.circular(Dimensions.height20),
                        ),
                      ),
                      child: Padding(
                        //填充组件
                        padding: EdgeInsets.only(
                          left: Dimensions.width10,
                          right: Dimensions.width10,
                        ),
                        child: Column(
                          //交叉轴对齐,左边
                          crossAxisAlignment: CrossAxisAlignment.start,
                          //主要的对齐
                          // mainAxisAlignment: MainAxisAlignment.spaceBetween,//两端对齐
                          mainAxisAlignment:
                              MainAxisAlignment.spaceAround, //空格环绕
                          // mainAxisAlignment: MainAxisAlignment.center, // 水平居中
                          children: [
                            BigText(text: "商品标题，商品标题，商品标题，商品标题，商品标题"),
                            SmallText(text: "商品介绍，商品介绍，商品介绍，商品介绍，商品介绍"),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                //使用组合图标和文字组件
                                IconAndTextWidget(
                                  icon: Icons.circle_sharp,
                                  iconColor: AppColors.iconColor1,
                                  text: "文字1",
                                ),
                                IconAndTextWidget(
                                  icon: Icons.location_on,
                                  iconColor: AppColors.mainColor,
                                  text: "文字2",
                                ),
                                IconAndTextWidget(
                                  icon: Icons.access_time_rounded,
                                  iconColor: AppColors.iconColor2,
                                  text: "文字3",
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            );
          },
        ),

        //====================列表部分
        //====================列表部分
      ],
      //======
    );
  }

  Widget _buildPageItem(int index) {
    //移动过程中的动画缩小至变大
    Matrix4 matrix = new Matrix4.identity();
    //当前页面的
    if (index == _currPageValue.floor()) {
      var currScale = 1 - (_currPageValue - index) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1)
        ..setTranslationRaw(0, currTrans, 0);
      //右边页面
    } else if (index == _currPageValue.floor() + 1) {
      var currScale =
          _scaleFactor + (_currPageValue - index + 1) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)
        ..setTranslationRaw(0, currTrans, 0);
      //左边页面
    } else if (index == _currPageValue.floor() - 1) {
      var currScale = 1 - (_currPageValue - index) * (1 - _scaleFactor);
      var currTrans = _height * (1 - currScale) / 2;
      matrix = Matrix4.diagonal3Values(1, currScale, 1);
      matrix = Matrix4.diagonal3Values(1, currScale, 1)
        ..setTranslationRaw(0, currTrans, 0);
      //其它页面
    } else {
      var currScale = 0.8;
      matrix = Matrix4.diagonal3Values(1, currScale, 1)
        ..setTranslationRaw(0, _height * (1 - _scaleFactor) / 2, 1);
    }

    return Transform(
      transform: matrix,
      child: Stack(
        //使用堆叠样式
        children: [
          //高度: 200,【左右的外边距10】【样式装饰-】
          Container(
            height: Dimensions.height220, //2时13分修改
            margin: EdgeInsets.only(
                left: Dimensions.width10, right: Dimensions.width10),
            decoration: BoxDecoration(
              //边框圆角30度
              borderRadius: BorderRadius.circular(Dimensions.radius30),
              //测试时背景颜色color: Color(0xFF69c5df),
              //单双数页面颜色不一样
              color: index.isEven ? AppColors.mainColor : AppColors.redColor,
              //填充图片
              image: DecorationImage(
                  fit: BoxFit.cover, image: AssetImage("images/gzn.jpg")),
            ),
          ),
          Align(
            //轮播图小框内容
            alignment: Alignment.bottomCenter, //对齐位置 底部
            child: Container(
              height: Dimensions.pageViewTextContainer, //2时14分修改
              margin: EdgeInsets.only(
                  left: Dimensions.width45,
                  right: Dimensions.width45,
                  bottom: Dimensions.height12),
              decoration: BoxDecoration(
                //边框眼样式圆角30度
                borderRadius: BorderRadius.circular(Dimensions.radius30),
                //测试时使用个背景颜色
                color: Colors.blue[500],
                //添加阴影【阴影1，主要阴影颜色】【阴影2，添加白色阴影来调节,左右】
                boxShadow: const [
                  //【阴影位置offset: Offset(5, 5),】【模糊半径blurRadius: 5.0,】
                  BoxShadow(
                      color: Color(0xFFe8e8e8),
                      blurRadius: 5.0,
                      offset: Offset(0, 5)),
                  BoxShadow(color: Colors.white, offset: Offset(-5, 0)),
                  BoxShadow(color: Colors.white, offset: Offset(5, 0)),
                ],
              ),
              child: Container(
                padding: EdgeInsets.only(
                    left: Dimensions.width10,
                    top: Dimensions.height10,
                    right: Dimensions.width10,
                    bottom: Dimensions.height10), //2时26分修改
                child: AppColumn(
                  text1: "轮播图小框内容",
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
