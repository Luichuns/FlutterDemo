import 'package:flutter/material.dart'; //安卓风格UI库
import 'package:my_app/utils/dimensions.dart'; //自定义容器在不同屏幕中的尺寸比例包
import 'package:my_app/utils/color.dart';
import 'package:my_app/widgets/big_text.dart';
import 'package:my_app/widgets/small_text.dart'; //自定义颜色组件
import 'package:my_app/pages/home/food_page_body.dart';

class MainFoodPage extends StatefulWidget {
  MainFoodPage({Key? key}) : super(key: key);

  @override
  State<MainFoodPage> createState() => _MainFoodPageState();
}

class _MainFoodPageState extends State<MainFoodPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: [
          Container(
            child: Container(
                margin: EdgeInsets.only(
                    top: Dimensions.height45, bottom: Dimensions.height15),
                padding: EdgeInsets.only(
                    left: Dimensions.width20, right: Dimensions.width20),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Column(
                      children: [
                        BigText(
                          text: "Malaysia",
                          color: AppColors.mainColor,
                        ),
                        Row(
                          children: [
                            SizedBox(
                              width: Dimensions.width30,
                            ),
                            SmallText(
                              text: "Malaysia",
                              color: Colors.black54,
                            ),
                            Icon(Icons.arrow_drop_down_rounded),
                          ],
                        )
                      ],
                    ),
                    Center(
                      child: Container(
                          width: Dimensions.width45,
                          height: Dimensions.height45,
                          child: Icon(Icons.search,
                              color: Colors.white, size: Dimensions.iconSize30),
                          decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(Dimensions.height15),
                            color: AppColors.mainColor,
                          )),
                    ),
                    
                  ],
                )),
          ),
          //列表部分
          Expanded(child: SingleChildScrollView(child: FoodPageBody(),)),
          //
        ],
      ),
    );
  }
}
