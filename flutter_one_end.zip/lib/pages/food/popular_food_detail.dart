import 'package:flutter/material.dart';
import 'package:get/get.dart'; //使用了getx导航方式
import 'package:my_app/controllers/cart_controller.dart';
import 'package:my_app/controllers/popular_product_controller.dart';
import 'package:my_app/data/repository/popular_product_repo.dart';
import 'package:my_app/models/products_model.dart';
import 'package:my_app/pages/cart/cart_page.dart';
import 'package:my_app/pages/home/main_food_page.dart';
import 'package:my_app/utils/app_constants.dart';
import 'package:my_app/utils/dimensions.dart';
import 'package:my_app/widgets/app_column.dart';
import 'package:my_app/widgets/app_icon.dart';
import 'package:my_app/widgets/exandable_text_widget.dart';

import 'package:my_app/utils/color.dart';
import 'package:my_app/widgets/big_text.dart';
import 'package:my_app/widgets/icon_and_text_widget.dart';
import 'package:my_app/widgets/small_text.dart';

class PopularFoodDetail extends StatelessWidget {
  final int pageId;
  const PopularFoodDetail({Key? key, required this.pageId}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var product =
        Get.find<PopularProductController>().popularProductList[pageId];
    Get.find<PopularProductController>()
        .initProduct(product, Get.find<CartController>());
    print("页面属于 ID 是" + pageId.toString());
    print("页面名字是 " + product.name.toString());
    //每次返回打开页面时，调用初始化 数量为0的函数

    return Scaffold(
      backgroundColor: Colors.white,
      body: Stack(
        children: [
          //定位方式组件
          //图片背景
          Positioned(
              left: 0,
              right: 0,
              child: Container(
                width: double.maxFinite,
                height: Dimensions.height350,
                decoration: BoxDecoration(
                  //填充图片
                  image: DecorationImage(
                    //填充拉满
                    fit: BoxFit.cover,
                    // image: AssetImage("images/gzn.jpg"),//更改为网络图片
                    //方式1
                    // image: NetworkImage(AppConstants.BASE_URL +
                    //     AppConstants.UPLOAD_URL +
                    //     product.img!),
                    //方式2
                    image: NetworkImage(AppConstants.BASE_URL +
                        AppConstants.UPLOAD_URL +
                        product.img.toString()),
                  ),
                ),
              )),
          //图标
          Positioned(
            //需要top才显示
            left: Dimensions.height30,
            right: Dimensions.height30,
            top: Dimensions.height40,
            // height: Dimensions.height40,

            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween, //两端对齐
              children: [
                GestureDetector(
                  onTap: () {
                    Get.to(() => MainFoodPage());
                  },
                  child: AppIcon(icon: Icons.arrow_back_ios),
                ),
                //
                //
                //
                GetBuilder<PopularProductController>(builder: (controller) {
                  return Stack(
                    children: [
                      AppIcon(icon: Icons.shopping_cart_checkout_outlined),
                      //三目运算  条件筛选显示颜色图标
                      Get.find<PopularProductController>().totalItems >= 1
                          ? Positioned(
                              right: 0,
                              top: 0,
                              child: GestureDetector(
                                onTap: () {
                                  Get.to(() => CartPage());
                                },
                                child: AppIcon(
                                  icon: Icons.circle,
                                  size: 20,
                                  iconColor: Colors.transparent,
                                  backgroundColor: AppColors.mainColor,
                                ),
                              ),
                            )
                          : Container(),
                      //三目运算  条件筛选显示文本
                      Get.find<PopularProductController>().totalItems >= 1
                          ? Positioned(
                              right: 2,
                              top: 2,
                              // left: 3,
                              // bottom: 3,
                              child: BigText(
                                text: Get.find<PopularProductController>()
                                    .totalItems
                                    .toString(),
                                size: 12,
                                color: Colors.white,
                              ),
                            )
                          : Container(),
                    ],
                  );
                }),
                //
                //
              ],
            ),
          ),
          //图片下方标题
          Positioned(
              //这里指定上下左右4个位置
              left: 0,
              right: 0,
              bottom: 0,
              top: Dimensions.height320, //设置在屏幕的位置,标记为这个定位的顶部
              child: Container(
                padding: EdgeInsets.only(
                    left: Dimensions.width20,
                    right: Dimensions.width20,
                    //top: Dimensions.height40,表示距离顶部高度
                    top: Dimensions.height20),
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      topRight: Radius.circular(Dimensions.height30),
                      topLeft: Radius.circular(Dimensions.height30),
                    ),
                    // color: Colors.redAccent),
                    color: Colors.white),
                child: Column(
                  //需要一个交叉轴的排列
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // AppColumn(text: "热卖食物详情页面"),
                    //更改为网络获取文字
                    // AppColumn(text: product.name!),
                    AppColumn(text: product.name.toString()),
                    SizedBox(height: Dimensions.height20),
                    BigText(text: "简介内容"),
                    SizedBox(height: Dimensions.height20),
                    SmallText(
                      text: "下面为长文本介绍",
                      size: Dimensions.font12,
                    ),
                    SizedBox(height: Dimensions.height20),
                    Expanded(
                        child: SingleChildScrollView(
                      // child: ExpandableTextWidget(text: "文字300可以伸缩"),
                      //更换为网络获取文字
                      // child: ExpandableTextWidget(text: product.description!),
                      //或者
                      child: ExpandableTextWidget(
                          text: product.description.toString()),
                    ))
                  ],
                ),
              ))
        ],
      ),
      //下面的数字加减 添加到购物车
      bottomNavigationBar: GetBuilder<PopularProductController>(
        builder: (popularProduct) {
          return Container(
            height: Dimensions.height120,
            padding: EdgeInsets.only(
              top: Dimensions.height10,
              left: Dimensions.width10,
              right: Dimensions.width10,
              bottom: Dimensions.height10,
            ),
            decoration: BoxDecoration(
              color: Colors.red,
              borderRadius: BorderRadius.only(
                  topRight: Radius.circular(Dimensions.height40),
                  topLeft: Radius.circular(Dimensions.height40)),
            ),
            //数字加减 添加到购物车
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween, //水平居中
              children: [
                //数字加减
                Container(
                  //上下边距
                  padding: EdgeInsets.only(
                      top: Dimensions.height15, bottom: Dimensions.height15),
                  //圆形边框
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(Dimensions.radius20),
                      color: Colors.white),
                  //-数字+
                  child: Row(
                    // mainAxisAlignment: MainAxisAlignment.spaceAround, //水平居中
                    children: [
                      SizedBox(width: Dimensions.width10),
                      GestureDetector(
                        onTap: () {
                          popularProduct.setQuantity(false);
                        },
                        child: Icon(
                          Icons.remove,
                          color: AppColors.signColor,
                          size: Dimensions.font16,
                        ),
                      ),
                      SizedBox(width: Dimensions.width10),
                      BigText(
                        // text:"0" ,
                        //更换为控制器里面创建的变量
                        // text: popularProduct.quantity.toString(),
                        //更换为已经在购物车中的数量
                        text: popularProduct.inCartItems.toString(),
                        size: Dimensions.font16,
                      ),
                      SizedBox(width: Dimensions.width10),
                      GestureDetector(
                        onTap: () {
                          popularProduct.setQuantity(true);
                        },
                        child: Icon(Icons.add,
                            color: AppColors.signColor,
                            size: Dimensions.font16),
                      ),
                      SizedBox(width: Dimensions.width5),
                    ],
                  ),
                ),
                //右边文字添加到购物车
                //163
                GestureDetector(
                  onTap: () {
                    popularProduct.addItem(product);
                  },
                  child: Container(
                    width: Dimensions.width200,
                    //上下边距
                    padding: EdgeInsets.only(
                        top: Dimensions.height15, bottom: Dimensions.height15),
                    //圆形边框
                    decoration: BoxDecoration(
                        borderRadius:
                            BorderRadius.circular(Dimensions.radius20),
                        color: AppColors.mainColor),
                    //-数字+
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround, //水平居中
                      children: [
                        BigText(
                          text: "\$ ${product.price} |添加并保存到购物车 ",
                          color: Colors.white,
                          size: Dimensions.font16,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
