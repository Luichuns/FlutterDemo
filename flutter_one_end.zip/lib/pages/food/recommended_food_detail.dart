import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_app/controllers/cart_controller.dart';
import 'package:my_app/controllers/popular_product_controller.dart';
import 'package:my_app/controllers/recommended_product_controller.dart';
import 'package:my_app/pages/cart/cart_page.dart';
import 'package:my_app/routes/route_helper.dart';
import 'package:my_app/utils/app_constants.dart';
import 'package:my_app/utils/color.dart';
import 'package:my_app/utils/dimensions.dart';
import 'package:my_app/widgets/app_icon.dart';
import 'package:my_app/widgets/big_text.dart';
import 'package:my_app/widgets/exandable_text_widget.dart';
import 'package:my_app/widgets/small_text.dart';

class RecommendedFoodDetail extends StatelessWidget {
  final int pageId;
  const RecommendedFoodDetail({Key? key, required this.pageId})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    //8-9 28 50添加
    var product =
        Get.find<RecommendedProductController>().recommendedProductList[pageId];
    //购物车控制器
    Get.find<PopularProductController>()
        .initProduct(product, Get.find<CartController>());
    return Scaffold(
      //使用背景颜色为白色
      backgroundColor: Colors.white,
      //需要一个可以上下滑动的页面
      body: CustomScrollView(
        //1条形部分，顶部
        slivers: [
          SliverAppBar(
            automaticallyImplyLeading: false, //添加后进入食物详情页面 不会出现图标分离 8-9 0647
            //设置title距离顶部高度
            toolbarHeight: 70,
            //1显示顶部的2个按钮
            title: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                //添加返回按钮 包裹
                GestureDetector(
                  onTap: () {
                    Get.toNamed(RouteHelper.getInitail());
                  },
                  child: AppIcon(icon: Icons.clear),
                ),

                //AppIcon(icon: Icons.shopping_cart_outlined),
                //
                //11-12 0315 添加
                //
                GetBuilder<PopularProductController>(builder: (controller) {
                  return Stack(
                    children: [
                      AppIcon(icon: Icons.shopping_cart_checkout_outlined),
                      //三目运算  条件筛选显示颜色图标
                      Get.find<PopularProductController>().totalItems >= 1
                          ? Positioned(
                              right: 0,
                              top: 0,
                              child: GestureDetector(
                                onTap: () {
                                  Get.to(() => CartPage());
                                },
                                child: AppIcon(
                                  icon: Icons.circle,
                                  size: 20,
                                  iconColor: Colors.transparent,
                                  backgroundColor: AppColors.mainColor,
                                ),
                              ),
                            )
                          : Container(),
                      //三目运算  条件筛选显示文本
                      Get.find<PopularProductController>().totalItems >= 1
                          ? Positioned(
                              right: 2,
                              top: 2,
                              // left: 3,
                              // bottom: 3,
                              child: BigText(
                                text: Get.find<PopularProductController>()
                                    .totalItems
                                    .toString(),
                                size: 12,
                                color: Colors.white,
                              ),
                            )
                          : Container(),
                    ],
                  );
                }
                    //
                    ),
                //
              ],
            ),
            //添加pinned属性,让上拉时可以卡在顶部100像素的位置
            pinned: true,
            //当卡主时，显示颜色
            backgroundColor: AppColors.yellowColor,
            //可扩展高度，这个条子可以上下拉
            expandedHeight: Dimensions.height300,
            flexibleSpace: FlexibleSpaceBar(
              //更换为网络图片
              // background: Image.asset(
              //   "images/gz.jpg",
              background: Image.network(
                //方式1AppConstants.BASE_URL+AppConstants.UPLOAD_URL+product.img!,
                //方式2AppConstants.BASE_URL +AppConstants.UPLOAD_URL +product.img.toString(),
                AppConstants.BASE_URL +
                    AppConstants.UPLOAD_URL +
                    product.img.toString(),
                //图片显示最大宽度
                width: double.maxFinite,
                //添加fit
                fit: BoxFit.cover,
              ),
            ),
            //在这个条子的地步显示文章的标题
            bottom: PreferredSize(
              //preferredSize: Size.fromHeight(20)设置条形显示被拉上后的停住高度
              preferredSize: Size.fromHeight(30),
              child: Container(
                //条子  标题的高度
                height: Dimensions.height35,
                //宽度
                width: double.maxFinite,
                //内边距
                padding: EdgeInsets.only(
                    top: Dimensions.height5, bottom: Dimensions.height5),
                // color: Colors.white,使用了装饰，那么颜色属性就在装饰里面定义
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                    topRight: Radius.circular(Dimensions.height20),
                    topLeft: Radius.circular(Dimensions.height20),
                  ),
                ),
                // padding: EdgeInsets.only(bottom: Dimensions.font1),

                child: Center(
                  child: BigText(
                    //本地固定文本
                    // text: "在条子底部的大文本标题",
                    //网络文本方式1
                    // text: product.name!,
                    //网络文本方式1
                    text: product.name.toString(),
                  ),
                ),
              ),
            ),
          ),
          //自定义滚动视图主题内的屏幕
          //给与盒子适配
          SliverToBoxAdapter(
            child: Column(
              children: [
                Container(
                  //添加边距，让看起来好看
                  margin: EdgeInsets.only(
                      left: Dimensions.width15, right: Dimensions.width15),
                  child: ExpandableTextWidget(
                    //本地固定文本
                    // text: "文本详情，文本详情，文本详情，文本详情文本详情",
                    //网络文本方式1
                    // text: product.description.toString(),
                    //网络文本方式2
                    text: product.description!,
                  ),
                )
              ],
            ),
          ),
        ],
      ),
      //添加底部导航栏的内容，这里更改为 添加数量，添加到购物车，以及价格显示
      bottomNavigationBar: GetBuilder<PopularProductController>(
        builder: ((controller) {
          return Column(
            //在Scaffold中直接使用Column，Column会直接占用所有主轴空间，需要给一个值
            //这里给最小值
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: EdgeInsets.only(
                  left: Dimensions.width50,
                  right: Dimensions.width50,
                  top: Dimensions.height10,
                  bottom: Dimensions.height10,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: () {
                        print("触发=减少按钮-");
                        //设置为数量添加
                        controller.setQuantity(false);
                      },
                      child: AppIcon(
                          iconSize: Dimensions.height24,
                          backgroundColor: AppColors.mainColor,
                          iconColor: Colors.white,
                          icon: Icons.remove),
                    ),
                    BigText(
                      //本地固定文本
                      // text: "10元/个",
                      //网络文本方式1
                      // text: product.description.toString(),
                      //网络文本方式2
                      // text: product.price.toString(),
                      //网络文本方式3
                      text: "\$ ${product.price!} X  ${controller.inCartItems}",
                      color: AppColors.mainBlackColor,
                      size: Dimensions.font20,
                    ),
                    GestureDetector(
                      onTap: () {
                        print("添加按钮测试+");
                        //设置为数量添加
                        controller.setQuantity(true);
                      },
                      child: AppIcon(
                          iconSize: Dimensions.height24,
                          backgroundColor: AppColors.mainColor,
                          iconColor: Colors.white,
                          icon: Icons.add),
                    ),
                  ],
                ),
              ),
              Container(
                height: Dimensions.height120,
                padding: EdgeInsets.only(
                  top: Dimensions.height10,
                  left: Dimensions.width10,
                  right: Dimensions.width10,
                  bottom: Dimensions.height10,
                ),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.only(
                      topRight: Radius.circular(Dimensions.height40),
                      topLeft: Radius.circular(Dimensions.height40)),
                ),
                //点赞图标
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween, //水平居中
                  children: [
                    //数字加减
                    Container(
                        //上下边距
                        padding: EdgeInsets.only(
                            top: Dimensions.height10,
                            bottom: Dimensions.height10,
                            left: Dimensions.width12,
                            right: Dimensions.width12),
                        //圆形边框
                        decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(Dimensions.radius20),
                            color: Colors.white),
                        //-数字+
                        child: Icon(
                          size: Dimensions.font30,
                          Icons.favorite,
                          color: AppColors.mainColor,
                        )),
                    //添加控制器包裹
                    GestureDetector(
                      onTap: () {
                        //点击后触发控制器的函数
                        controller.addItem(product);
                      },
                      child: Container(
                        width: Dimensions.width200,
                        //上下边距
                        padding: EdgeInsets.only(
                            top: Dimensions.height15,
                            bottom: Dimensions.height15),
                        //圆形边框
                        decoration: BoxDecoration(
                            borderRadius:
                                BorderRadius.circular(Dimensions.radius20),
                            color: AppColors.mainColor),
                        //-数字+
                        child: Row(
                          mainAxisAlignment:
                              MainAxisAlignment.spaceAround, //水平居中
                          children: [
                            BigText(
                              text: "\$ ${product.price!} |添加到购物车 ",
                              color: Colors.white,
                              size: Dimensions.font16,
                            ),
                          ],
                        ),
                      ),
                    ),
                    //右边文字添加到购物车
                  ],
                ),
              ),
            ],
          );
        }),
      ),
    );
  }
}
