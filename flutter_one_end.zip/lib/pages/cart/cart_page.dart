import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/state_manager.dart';
import 'package:my_app/controllers/cart_controller.dart';
import 'package:my_app/pages/home/main_food_page.dart';
import 'package:my_app/utils/app_constants.dart';
import 'package:my_app/utils/color.dart';
import 'package:my_app/utils/dimensions.dart';
import 'package:my_app/widgets/app_icon.dart';
import 'package:my_app/widgets/big_text.dart';
import 'package:my_app/widgets/small_text.dart';

class CartPage extends StatelessWidget {
  const CartPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          //
          //
          //顶部3个图标
          Positioned(
            left: Dimensions.height60,
            top: Dimensions.width20,
            right: Dimensions.width20,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                AppIcon(
                  icon: Icons.arrow_back_ios,
                  iconColor: Colors.white,
                  backgroundColor: AppColors.mainColor,
                  iconSize: Dimensions.iconSize24,
                ),
                SizedBox(width: Dimensions.width100),
                GestureDetector(
                  onTap: () {
                    Get.to(() => MainFoodPage());
                  },
                  child: AppIcon(
                    icon: Icons.home_outlined,
                    iconColor: Colors.white,
                    backgroundColor: AppColors.mainColor,
                    iconSize: Dimensions.iconSize24,
                  ),
                ),
                AppIcon(
                  icon: Icons.shopping_cart,
                  iconColor: Colors.white,
                  backgroundColor: AppColors.mainColor,
                  iconSize: Dimensions.iconSize24,
                ),
              ],
            ),
          ),
          //
          //
          //购物车列表
          Positioned(
              top: Dimensions.height100,
              left: Dimensions.width10,
              right: Dimensions.width10,
              bottom: 20,
              child: Container(
                margin: EdgeInsets.only(top: Dimensions.height15),
                color: Colors.blue[200],
                child: MediaQuery.removePadding(
                  context: context,
                  removeTop: true,
                  child: GetBuilder<CartController>(builder: (cartController) {
                    return ListView.builder(
                      itemCount: cartController.getItems.length,
                      itemBuilder: (_, index) {
                        return Container(
                          width: double.infinity,
                          height: Dimensions.height100,
                          // color: Colors.amber[900],
                          child: Row(
                            children: [
                              //
                              //左边图片
                              Container(
                                margin: EdgeInsets.only(
                                    bottom: Dimensions.height10),
                                width: Dimensions.width100,
                                height: Dimensions.height100,
                                // color: Colors.blueGrey,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(
                                      Dimensions.radius20),
                                  image: DecorationImage(
                                    fit: BoxFit.cover,
                                    // image: AssetImage("images/gzn.jpg"),
                                    image: NetworkImage(AppConstants.BASE_URL +
                                        AppConstants.UPLOAD_URL +
                                        cartController.getItems[index].img
                                            .toString()),
                                  ),
                                ),
                              ),
                              //
                              //
                              SizedBox(width: Dimensions.width10),
                              //右边文字和2按钮
                              Expanded(
                                child: Container(
                                  height: Dimensions.height100,
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceEvenly,
                                    children: [
                                      BigText(
                                        // text: "商品标题Product Title",
                                        text: cartController
                                            .getItems[index].name!,
                                        color: Colors.black54,
                                      ),
                                      SmallText(
                                        text: "商品小文字",
                                        color: Colors.blueGrey[800],
                                      ),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceBetween,
                                        children: [
                                          BigText(
                                            // text: "价格\$33",
                                            text: cartController
                                                .getItems[index].price
                                                .toString(),
                                            color: Colors.redAccent,
                                          ),
                                          //数字加减
                                          Container(
                                            //上下边距
                                            padding: EdgeInsets.only(
                                                top: Dimensions.height5,
                                                bottom: Dimensions.height5,
                                                left: Dimensions.width5,
                                                right: Dimensions.width5),
                                            //圆形边框
                                            decoration: BoxDecoration(
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        Dimensions.radius20),
                                                color: Colors.white),
                                            //-数字+
                                            child: Row(
                                              // mainAxisAlignment: MainAxisAlignment.spaceAround, //水平居中
                                              children: [
                                                SizedBox(
                                                    width: Dimensions.width10),
                                                GestureDetector(
                                                  onTap: () {
                                                    //popularProduct.setQuantity(false);
                                                  },
                                                  child: Icon(
                                                    Icons.remove,
                                                    color: AppColors.signColor,
                                                    size: Dimensions.font16,
                                                  ),
                                                ),
                                                SizedBox(
                                                    width: Dimensions.width10),
                                                BigText(
                                                  // text:"0" ,
                                                  //更换为控制器里面创建的变量
                                                  // text: popularProduct.quantity.toString(),
                                                  //更换为已经在购物车中的数量
                                                  text:
                                                      "0", //popularProduct.inCartItems.toString(),
                                                  size: Dimensions.font16,
                                                ),
                                                SizedBox(
                                                    width: Dimensions.width10),
                                                GestureDetector(
                                                  onTap: () {
                                                    //popularProduct.setQuantity(true);
                                                  },
                                                  child: Icon(Icons.add,
                                                      color:
                                                          AppColors.signColor,
                                                      size: Dimensions.font16),
                                                ),
                                                SizedBox(
                                                    width: Dimensions.width5),
                                              ],
                                            ),
                                          ),
                                          //右边文字添加到购物车
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                        );
                      },
                    );
                    //
                  }),

                  //
                  //
                ),
                //
              )),
          //
        ],
      ),
    );
  }
}
