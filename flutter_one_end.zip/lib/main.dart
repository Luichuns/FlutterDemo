library main;

import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';

//控制器添加
import 'package:my_app/controllers/popular_product_controller.dart';
import 'package:my_app/controllers/recommended_product_controller.dart';

// import 'package:my_app/pages/home/ex.c';
import 'package:my_app/routes/route_helper.dart'; //路由
import 'package:my_app/utils/color.dart';
import 'package:my_app/utils/dimensions.dart';
import 'package:get/get.dart';
import 'package:my_app/pages/home/main_food_page.dart'; //home页面
// food
import 'package:my_app/pages/food/popular_food_detail.dart'; //食物详情页面
import 'package:my_app/pages/food/recommended_food_detail.dart';

//测试页面
// import 'package:my_app/testhome/test1.dart';
// import 'package:my_app/testhome/test2.dart';

//5-6 51：16
import 'package:my_app/helper/dependencies.dart';
import 'package:my_app/helper/dependencies.dart' as dep;

import 'pages/cart/cart_page.dart';

Future<void> main() async {
  //绑定,用于确保 初始化，
  WidgetsFlutterBinding.ensureInitialized();
  //依赖项加载
  await dep.init();
  runApp(const MyApp());
}
// void main() {
//   runApp(const MyApp());
// }

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    //
    //
    //6-7 43分//报错
    //加载数据
    //需要调用方法加载数据
    Get.find<PopularProductController>().getPopularProductList();
    Get.find<RecommendedProductController>().getRecommendedProductList();
    //使用Getx--改变1：使用GetMaterialApp()作为应用的顶层
    return GetMaterialApp(
      title: '应用名luichun',
      //7-8 4756 取消使用
      // theme: ThemeData(fontFamily: 'SourceSansPro',primarySwatch: Colors.blue,),
      // home: RecommendedFoodDetail(),
      // home: const RecommendedFoodDetail(),
      // home: PopularFoodDetail(), //第2个页面
      home: MainFoodPage(),
      // home: CartPage(),//购物车页面
      // home: FoodPageBody(),
      // home: Home(),测试页面
      // debugShowCheckedModeBanner: true,
      debugShowCheckedModeBanner: false,
      //取消 7-8 5206
      //11-12 1945注释//home: MainFoodPage(),需要的下面两个
      initialRoute: RouteHelper.initial,
      getPages: RouteHelper.routes,
      //11-12 1945注释
    );
  }
}

// class MyHomePage extends StatefulWidget {
//   const MyHomePage({Key? key}) : super(key: key);

//   @override
//   State<MyHomePage> createState() => _MyHomePageState();
// }

// class _MyHomePageState extends State<MyHomePage> {
//   @override
//   Widget build(BuildContext context) {
//     print("屏幕高度是" + MediaQuery.of(context).size.height.toString());
//     print("current heigt is" + MediaQuery.of(context).size.height.toString());
//     print("屏幕宽度是" + MediaQuery.of(context).size.width.toString());
//     print("current width is" + MediaQuery.of(context).size.width.toString());
//     return Scaffold(
//       body: Center(child: MainFoodPage()),
//     );
//   }
// }
