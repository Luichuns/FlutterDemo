Scaffold
23个属性
|字段|属性|解析|
|:-|:-|:-|
appBar	|PreferredSizeWidget	|显示脚手架的顶部导航区|
body	|Widget	|显示脚手架的主要内容|
floatingActionButton	|Widget	|悬浮按钮，位于右下角|
floatingActionButtonLocation	|FloatingActionButtonLocation	|决定悬浮按钮的位置|
floatingActionButtonAnimator	|FloatingActionButtonAnimator	|决定悬浮按钮的动画|
persistentFooterButtons	|List	|显示在脚手架底部的一组按钮|
drawer	|Widget	|左侧抽屉菜单组件|
onDrawerChanged	|DrawerCallback	|左侧抽屉菜单改变事件回调|
endDrawer	|Widget	|右侧抽屉菜单组件
onEndDrawerChanged	|DrawerCallback	|右侧抽屉菜单改变事件回调|
bottomNavigationBar	|Widget	|底部导航条
bottomSheet	|Widget	|持久在body下方，底部控件上方的控件|
backgroundColor	|Color	|脚手架背景颜色|
resizeToAvoidBottomInset	|bool	|防止小组件重复|
primary	|bool	|脚手架是否延伸到顶部
drawerDragStartBehavior	|DragStartBehavior	|检测手势行为方式，与drawer配合使用|
extendBody	|bool	|是否延伸到底部|
extendBodyBehindAppBar	|bool	|是否延伸到顶部，用于做半透明、毛玻璃效果的主要控制属性|
drawerScrimColor	|Color	|侧边栏弹出时非遮盖层主页面的颜色|
drawerEdgeDragWidth	|double|	侧边栏弹出时非遮罩层的宽度|
drawerEnableOpenDragGesture	|bool	|左侧抽屉是否支持手势滑动|
endDrawerEnableOpenDragGesture	|bool	|右侧抽屉是否支持手势滑动|
restorationId	|String	|状态还原标识符|