Scaffold(
        显示脚手架的顶部导航栏
        appBar: AppBar(title: Text("Scaffold"),),
        显示脚手架的主要内容
        body: Center(child: Text("body"),),
        悬浮按钮，默认位于右小角
        floatingActionButton: FloatingActionButton(
                                                    onPressed: (){print("add");},
                                                    child: Icon(Icons.add)
                                                  ),
        决定悬浮按钮的位置
        floatingActionButtonLocation: FloatingActionButtonLocation.miniCenterDocked,
        决定悬浮按钮的动画
        floatingActionButtonAnimator: FloatingActionButtonAnimator.scaling,
        显示在脚手架底部的一组按钮
        persistentFooterButtons: [
                                    TextButton(onPressed: (){}, child: Text("Text1")),
                                    TextButton(onPressed: (){}, child: Text("Text2")),
                                 ],
  );