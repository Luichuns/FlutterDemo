class AppConstants {
  static const String APP_NAME = "DBfood";
  static const int APP_VERSION = 1;
  static const String BASE_URL = "https://mvs.bslmeiyu.com";
  static const String POPULAR_PRODUCT_URI = "/api/v1/products/popular/";
  static const String RECOMMENDED_PRODUCT_URI = "/api/v1/products/recommended/";
  static const String TOKEN = "DBtoken"; //令牌
  static const String UPLOAD_URL = "/uploads/"; //后端上传文件夹名字
  static const String TUPIAN = "https://mvs.bslmeiyu.com/uploads/"; //域名+图片文件夹

}
// 这个是应用使用的常量列表库
//存放主网站域名